import type { Metadata, Viewport } from "next";
import "./globals.css";
import AppHeader from "@/components/AppHeader";
import BottomNav from "@/components/BottomNav";
import PWARegister from "@/components/PWARegister";

export const metadata: Metadata = {
  title: "SamaCampus 221 — Révise ton semestre en 15 min/jour",
  description: "L'app de révision des étudiants sénégalais : audio, flashcards, quiz et classement par université.",
  manifest: "/manifest.json",
  applicationName: "SamaCampus 221",
  appleWebApp: { capable: true, title: "SamaCampus", statusBarStyle: "black-translucent" },
  icons: { icon: "/icons/icon-192.png", apple: "/icons/apple-touch-icon.png" },
};

export const viewport: Viewport = {
  themeColor: "#6C5CE7",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>
        <div className="relative mx-auto min-h-screen max-w-md bg-[#F7F5FF] shadow-2xl">
          <AppHeader />
          <main className="px-4 pb-28 pt-3">{children}</main>
          <BottomNav />
        </div>
        <PWARegister />
      </body>
    </html>
  );
}
