"use client";
import Link from "next/link";
import { motion } from "framer-motion";
import CountUp from "@/components/CountUp";
import InstallButton from "@/components/InstallButton";
import { COURSES, MATIERES } from "@/lib/data";

const fadeUp = {
  hidden: { opacity: 0, y: 18 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.08, type: "spring" as const, stiffness: 200, damping: 20 } }),
};

export default function Home() {
  return (
    <div className="space-y-6">
      {/* HERO */}
      <motion.section
        initial="hidden"
        animate="show"
        className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-yello-dark via-yello to-yello-light p-6 text-white shadow-card"
      >
        <span className="absolute -right-6 -top-6 text-8xl opacity-20">🇸🇳</span>
        <motion.p variants={fadeUp} custom={0} className="inline-block rounded-full bg-white/20 px-3 py-1 text-xs font-black">
          🎓 Pour les étudiants sénégalais
        </motion.p>
        <motion.h1 variants={fadeUp} custom={1} className="mt-3 text-4xl font-black leading-tight">
          SamaCampus <span className="text-sn-yellow">221</span> <span className="inline-block animate-floaty">🚀</span>
        </motion.h1>
        <motion.p variants={fadeUp} custom={2} className="mt-2 text-lg font-bold text-white/90">
          Révise ton semestre en <span className="rounded-lg bg-sn-green px-1.5">15 min/jour</span> ⏱️
        </motion.p>
        <motion.div variants={fadeUp} custom={3} className="mt-5 flex flex-col gap-3">
          <Link href="/login" className="btn-green w-full !bg-sn-yellow !text-ink !shadow-[0_5px_0_0_#C9BB1A] text-lg">
            🎯 Commencer gratuitement
          </Link>
          <Link href="/cours/algo-l1" className="text-center text-sm font-bold text-white/90 underline underline-offset-4">
            Essayer sans compte →
          </Link>
        </motion.div>
      </motion.section>

      {/* STATS */}
      <section className="grid grid-cols-3 gap-3">
        {[
          { n: 2500, s: "", l: "étudiants", e: "👩🏾‍🎓" },
          { n: 15000, s: "", l: "quiz générés", e: "🧠" },
          { n: 92, s: "%", l: "valident", e: "✅" },
        ].map((x, i) => (
          <motion.div
            key={x.l}
            initial={{ opacity: 0, scale: 0.85 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="card text-center !p-3"
          >
            <div className="text-2xl">{x.e}</div>
            <CountUp to={x.n} suffix={x.s} className="block text-xl font-black text-yello-dark" />
            <div className="text-[11px] font-bold text-ink/60">{x.l}</div>
          </motion.div>
        ))}
      </section>

      {/* MATIÈRES */}
      <section>
        <h2 className="mb-3 text-xl font-black">📚 Choisis ta matière</h2>
        <div className="grid grid-cols-2 gap-3">
          {MATIERES.map((m, i) => {
            const n = COURSES.filter((c) => c.matiere === m.id).length;
            return (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.07 }}
                whileTap={{ scale: 0.95 }}
              >
                <Link
                  href={`/cours/${m.first}`}
                  className={`block h-36 rounded-3xl bg-gradient-to-br ${m.color} p-4 text-white shadow-card`}
                >
                  <div className="text-4xl">{m.emoji}</div>
                  <div className="mt-3 text-lg font-black leading-tight">{m.label}</div>
                  <div className="text-xs font-bold text-white/85">{n} cours · audio + quiz</div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* DÉFI */}
      <Link href="/quiz?mix=1" className="block">
        <motion.div whileTap={{ scale: 0.97 }} className="card flex items-center gap-4 border-2 border-sn-green/30">
          <span className="animate-floaty text-4xl">⚡</span>
          <div className="flex-1">
            <p className="font-black">Défi du jour</p>
            <p className="text-sm font-semibold text-ink/60">10 questions chrono · gagne jusqu'à 300 XP</p>
          </div>
          <span className="text-2xl">➡️</span>
        </motion.div>
      </Link>

      {/* TOUS LES COURS */}
      <section>
        <h2 className="mb-3 text-xl font-black">🔥 Tous les cours L1</h2>
        <div className="space-y-2">
          {COURSES.map((c) => (
            <Link key={c.id} href={`/cours/${c.id}`} className="card flex items-center gap-3 !p-3 active:scale-[0.98]">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-yello-soft text-2xl">{c.emoji}</span>
              <div className="flex-1">
                <p className="font-extrabold">{c.titre}</p>
                <p className="text-xs font-semibold text-ink/50">
                  {c.niveau} · 🎧 {c.duree_min} min · 🃏 {c.flashcards.length} cartes
                </p>
              </div>
              <span className="text-yello">▶</span>
            </Link>
          ))}
        </div>
      </section>

      <Link href="/generate" className="block rounded-3xl bg-ink p-5 text-white shadow-card">
        <p className="text-sm font-black text-sn-yellow">✨ NOUVEAU</p>
        <p className="text-lg font-black">Colle ton cours, l'IA crée tes flashcards 🤖</p>
        <p className="text-sm text-white/70">10 flashcards + 5 QCM en quelques secondes.</p>
      </Link>

      <InstallButton />
    </div>
  );
}
