"use client";
import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { UNIVERSITES } from "@/lib/data";
import { BADGES, displayStreak, useProgress } from "@/lib/progress";
import { supabase } from "@/lib/supabase";

type Row = { pseudo: string; uni: string; xp: number; streak: number; me?: boolean };

const MOCK: Row[] = [
  { pseudo: "Aminata D.", uni: "UCAD", xp: 4820, streak: 21 },
  { pseudo: "Cheikh Ba", uni: "UCAD", xp: 4310, streak: 14 },
  { pseudo: "Fatou Sow", uni: "UGB", xp: 4150, streak: 18 },
  { pseudo: "Moussa Ndiaye", uni: "UGB", xp: 3720, streak: 9 },
  { pseudo: "Awa Diop", uni: "UVS", xp: 3480, streak: 12 },
  { pseudo: "Ibrahima Fall", uni: "UCAD", xp: 3390, streak: 7 },
  { pseudo: "Khadija Sy", uni: "UADB", xp: 2960, streak: 11 },
  { pseudo: "Modou Gueye", uni: "UVS", xp: 2740, streak: 5 },
  { pseudo: "Mariama Cissé", uni: "UADB", xp: 2510, streak: 8 },
  { pseudo: "Abdou Sarr", uni: "UGB", xp: 2260, streak: 4 },
  { pseudo: "Ndeye Faye", uni: "UCAD", xp: 1980, streak: 6 },
  { pseudo: "Pape Thiam", uni: "UADB", xp: 1650, streak: 3 },
];

const MEDALS = ["🥇", "🥈", "🥉"];

export default function Leaderboard() {
  const { p, update } = useProgress();
  const [tab, setTab] = useState<"uni" | "etu">("uni");
  const [remote, setRemote] = useState<Row[] | null>(null);

  useEffect(() => {
    if (!supabase) return;
    supabase
      .from("users")
      .select("pseudo, universite, xp, streak")
      .order("xp", { ascending: false })
      .limit(50)
      .then(({ data }) => {
        if (data?.length) setRemote(data.map((d) => ({ pseudo: d.pseudo, uni: d.universite, xp: d.xp, streak: d.streak })));
      });
  }, []);

  const rows = useMemo(() => {
    const base = remote ?? MOCK;
    const me: Row = { pseudo: `${p.pseudo} (toi)`, uni: p.uni, xp: p.xp, streak: displayStreak(p), me: true };
    return [...base, me].sort((a, b) => b.xp - a.xp);
  }, [p, remote]);

  const unis = useMemo(
    () =>
      UNIVERSITES.map((u) => {
        const members = rows.filter((r) => r.uni === u.id);
        return { ...u, xp: members.reduce((s, r) => s + r.xp, 0), n: members.length };
      }).sort((a, b) => b.xp - a.xp),
    [rows]
  );
  const maxUni = Math.max(1, ...unis.map((u) => u.xp));

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-black">🏆 Classement</h1>
        <p className="text-sm font-semibold text-ink/60">Fais gagner des points à ta fac !</p>
      </div>

      <div className="card !p-3">
        <label className="text-xs font-black text-ink/50">🎓 MA FAC</label>
        <div className="mt-1 flex flex-wrap gap-2">
          {UNIVERSITES.map((u) => (
            <button
              key={u.id}
              onClick={() => update({ uni: u.id })}
              className={`rounded-full px-3 py-1.5 text-sm font-extrabold ${p.uni === u.id ? "bg-yello text-white" : "bg-yello-soft text-yello-dark"}`}
            >
              {u.emoji} {u.nom}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-1 rounded-2xl bg-yello/10 p-1 text-sm font-extrabold">
        {(["uni", "etu"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`rounded-xl py-2 ${tab === t ? "bg-white text-yello-dark shadow" : "text-ink/50"}`}>
            {t === "uni" ? "🏛️ Universités" : "🧑🏾‍🎓 Étudiants"}
          </button>
        ))}
      </div>

      {tab === "uni" ? (
        <div className="space-y-3">
          {unis.map((u, i) => (
            <motion.div key={u.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.08 }} className="card">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{MEDALS[i] ?? `#${i + 1}`}</span>
                <div className="flex-1">
                  <p className="font-black">
                    {u.emoji} {u.nom} <span className="text-xs font-semibold text-ink/50">· {u.ville}</span>
                  </p>
                  <p className="text-xs font-semibold text-ink/50">{u.n} étudiants actifs</p>
                </div>
                <p className="font-black text-yello-dark">{u.xp.toLocaleString("fr-FR")} ⭐</p>
              </div>
              <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-yello/15">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-yello to-sn-green"
                  initial={{ width: 0 }}
                  animate={{ width: `${(u.xp / maxUni) * 100}%` }}
                  transition={{ duration: 0.9, delay: i * 0.08 }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="space-y-2">
          {rows.slice(0, 15).map((r, i) => (
            <motion.div
              key={r.pseudo + i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
              className={`card flex items-center gap-3 !p-3 ${r.me ? "border-2 border-sn-green bg-green-50" : ""}`}
            >
              <span className="w-8 text-center text-xl font-black">{MEDALS[i] ?? i + 1}</span>
              <div className="flex-1">
                <p className="font-extrabold">{r.pseudo}</p>
                <p className="text-xs font-semibold text-ink/50">
                  {r.uni} · 🔥 {r.streak} j
                </p>
              </div>
              <p className="font-black text-yello-dark">{r.xp.toLocaleString("fr-FR")} ⭐</p>
            </motion.div>
          ))}
        </div>
      )}

      <section>
        <h2 className="mb-2 text-xl font-black">🎖️ Tes badges</h2>
        <div className="grid grid-cols-2 gap-3">
          {BADGES.map((b) => {
            const has = p.badges.includes(b.id);
            return (
              <div key={b.id} className={`card text-center !p-3 ${has ? "" : "opacity-50 grayscale"}`}>
                <div className="text-4xl">{has ? b.emoji : "🔒"}</div>
                <p className="mt-1 font-black">{b.nom}</p>
                <p className="text-xs font-semibold text-ink/60">{b.desc}</p>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
