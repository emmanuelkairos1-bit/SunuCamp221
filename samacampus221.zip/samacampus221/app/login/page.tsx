"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { UNIVERSITES } from "@/lib/data";
import { levelOf, useProgress } from "@/lib/progress";
import { hasSupabase, supabase } from "@/lib/supabase";

export default function LoginPage() {
  const router = useRouter();
  const { p, update } = useProgress();
  const [mode, setMode] = useState<"signup" | "signin">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [pseudo, setPseudo] = useState("");
  const [uni, setUni] = useState("UCAD");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);

  useEffect(() => {
    supabase?.auth.getSession().then(({ data }) => setUserEmail(data.session?.user.email ?? null));
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    if (!supabase) {
      // Mode démo : on enregistre juste le profil en local
      update({ pseudo: pseudo || "Toi", uni });
      router.push("/cours/algo-l1");
      return;
    }
    setBusy(true);
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { pseudo: pseudo || email.split("@")[0], universite: uni } },
        });
        if (error) throw error;
        update({ pseudo: pseudo || email.split("@")[0], uni });
        if (data.session) router.push("/");
        else setMsg("📧 Vérifie ta boîte mail pour confirmer ton compte, puis connecte-toi.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        router.push("/");
      }
    } catch (err) {
      setMsg("⚠️ " + (err instanceof Error ? err.message : "Erreur"));
    } finally {
      setBusy(false);
    }
  };

  const { level, into, next } = levelOf(p.xp);

  return (
    <div className="space-y-4">
      <div className="rounded-3xl bg-gradient-to-br from-yello-dark to-yello p-5 text-white shadow-card">
        <div className="flex items-center gap-3">
          <span className="grid h-16 w-16 place-items-center rounded-2xl bg-white/20 text-4xl">🧑🏾‍🎓</span>
          <div>
            <p className="text-xl font-black">{p.pseudo}</p>
            <p className="text-sm font-bold text-white/80">
              {p.uni} · Niveau {level} {userEmail ? `· ${userEmail}` : ""}
            </p>
          </div>
        </div>
        <div className="mt-3 h-3 overflow-hidden rounded-full bg-white/25">
          <div className="h-full rounded-full bg-sn-yellow" style={{ width: `${(into / next) * 100}%` }} />
        </div>
        <p className="mt-1 text-xs font-bold text-white/80">
          ⭐ {p.xp} XP · encore {next - into} XP pour le niveau {level + 1}
        </p>
      </div>

      {userEmail ? (
        <button
          className="btn-ghost w-full"
          onClick={async () => {
            await supabase?.auth.signOut();
            setUserEmail(null);
          }}
        >
          👋 Se déconnecter
        </button>
      ) : (
        <form onSubmit={submit} className="card space-y-3">
          <h1 className="text-xl font-black">{mode === "signup" ? "🚀 Crée ton compte gratuit" : "👋 Content de te revoir"}</h1>
          {!hasSupabase && (
            <p className="rounded-xl bg-amber-100 p-2 text-xs font-bold text-amber-900">
              Mode démo : Supabase n'est pas configuré, ta progression est sauvegardée sur ce téléphone.
            </p>
          )}
          {mode === "signup" && (
            <>
              <input
                value={pseudo}
                onChange={(e) => setPseudo(e.target.value)}
                placeholder="Ton pseudo (ex : Aminata D.)"
                className="w-full rounded-2xl border-2 border-yello/20 p-3 font-semibold outline-none focus:border-yello"
              />
              <div className="flex flex-wrap gap-2">
                {UNIVERSITES.map((u) => (
                  <button
                    type="button"
                    key={u.id}
                    onClick={() => setUni(u.id)}
                    className={`rounded-full px-3 py-1.5 text-sm font-extrabold ${uni === u.id ? "bg-yello text-white" : "bg-yello-soft text-yello-dark"}`}
                  >
                    {u.emoji} {u.nom}
                  </button>
                ))}
              </div>
            </>
          )}
          {hasSupabase && (
            <>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                className="w-full rounded-2xl border-2 border-yello/20 p-3 font-semibold outline-none focus:border-yello"
              />
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Mot de passe (6 caractères min.)"
                className="w-full rounded-2xl border-2 border-yello/20 p-3 font-semibold outline-none focus:border-yello"
              />
            </>
          )}
          {msg && <p className="text-sm font-bold text-sn-red">{msg}</p>}
          <button className="btn-pop w-full" disabled={busy}>
            {busy ? "⏳…" : mode === "signup" ? "🎯 C'est parti !" : "Se connecter"}
          </button>
          {hasSupabase && (
            <button type="button" className="w-full text-sm font-bold text-yello-dark underline" onClick={() => setMode(mode === "signup" ? "signin" : "signup")}>
              {mode === "signup" ? "J'ai déjà un compte" : "Créer un compte"}
            </button>
          )}
        </form>
      )}
    </div>
  );
}
