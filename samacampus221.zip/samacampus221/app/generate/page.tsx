"use client";
import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import FlashcardDeck from "@/components/FlashcardDeck";
import { generate, Generated, SAMPLE_TEXT } from "@/lib/mockAI";
import { useProgress } from "@/lib/progress";

const STEPS = [
  "📖 Lecture de ton cours…",
  "🧠 Extraction des notions clés…",
  "🃏 Création des 10 flashcards…",
  "🎯 Rédaction des 5 QCM…",
  "✨ Finalisation…",
];

export default function GeneratePage() {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(0);
  const [result, setResult] = useState<Generated | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const { record } = useProgress();

  const run = () => {
    if (text.trim().length < 20) return;
    setLoading(true);
    setResult(null);
    setStep(0);
    const iv = setInterval(() => setStep((s) => Math.min(STEPS.length - 1, s + 1)), 650);
    setTimeout(() => {
      clearInterval(iv);
      const r = generate(text);
      setResult(r);
      setLoading(false);
      record({ xp: 20 });
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
    }, 3200);
  };

  const launchQuiz = () => {
    if (!result) return;
    try {
      sessionStorage.setItem("samacampus:generated-quiz", JSON.stringify(result.qcm));
    } catch {}
    router.push("/quiz?source=generated");
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-black">🤖 Générateur IA</h1>
        <p className="text-sm font-semibold text-ink/60">Colle ton cours, on le transforme en flashcards et QCM.</p>
      </div>

      <div className="card space-y-3">
        <label htmlFor="cours" className="font-extrabold">
          📋 Colle ton cours
        </label>
        <textarea
          id="cours"
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={9}
          placeholder="Colle ici ton cours, tes notes ou ton polycopié (minimum 2-3 phrases)…"
          className="w-full resize-none rounded-2xl border-2 border-yello/20 bg-yello-soft/50 p-3 text-[15px] outline-none focus:border-yello"
        />
        <div className="flex items-center justify-between text-xs font-bold text-ink/50">
          <span>{text.length} caractères</span>
          <button className="text-yello underline" onClick={() => setText(SAMPLE_TEXT)}>
            ✏️ Utiliser un exemple (Droit)
          </button>
        </div>
        <button className="btn-pop w-full disabled:opacity-50" disabled={loading || text.trim().length < 20} onClick={run}>
          {loading ? "⏳ L'IA travaille…" : "✨ Générer 10 flashcards + 5 QCM"}
        </button>
      </div>

      <AnimatePresence>
        {loading && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="card text-center">
            <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 2, ease: "linear" }} className="mx-auto inline-block text-5xl">
              🧠
            </motion.div>
            <p className="mt-2 font-extrabold">{STEPS[step]}</p>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-yello/15">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-yello to-sn-green"
                animate={{ width: `${((step + 1) / STEPS.length) * 100}%` }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {result && (
        <motion.div ref={resultRef} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <div className="rounded-3xl bg-gradient-to-r from-sn-green to-sn-lime p-4 text-white shadow-card">
            <p className="text-lg font-black">🎉 C'est prêt ! +20 XP</p>
            <p className="text-sm font-semibold text-white/90">
              Thème détecté : {result.topicLabel} · {result.flashcards.length} flashcards · {result.qcm.length} QCM
            </p>
            {result.fromText < 10 && (
              <p className="mt-1 text-xs font-semibold text-white/80">
                {result.fromText} cartes tirées de ton texte, complétées par des notions clés du programme.
              </p>
            )}
          </div>

          <FlashcardDeck cards={result.flashcards} onKnow={() => {}} />

          <button className="btn-pop w-full" onClick={launchQuiz}>
            🎯 Lancer les 5 QCM chronométrés
          </button>
        </motion.div>
      )}
    </div>
  );
}
