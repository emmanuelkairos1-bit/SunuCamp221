import { notFound } from "next/navigation";
import { COURSES, localCourse } from "@/lib/data";
import CourseView from "./CourseView";

export function generateStaticParams() {
  return COURSES.map((c) => ({ id: c.id }));
}

export default function CoursPage({ params }: { params: { id: string } }) {
  const course = localCourse(params.id);
  if (!course) notFound();
  return <CourseView initial={course} />;
}
