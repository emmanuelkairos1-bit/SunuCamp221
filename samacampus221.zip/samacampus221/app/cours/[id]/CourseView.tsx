"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import AudioPlayer from "@/components/AudioPlayer";
import FlashcardDeck from "@/components/FlashcardDeck";
import Resume from "@/components/Resume";
import { Course, fetchCourse } from "@/lib/data";
import { useProgress } from "@/lib/progress";

const TABS = [
  { id: "audio", label: "Audio", emoji: "🎧" },
  { id: "resume", label: "Résumé", emoji: "📝" },
  { id: "cards", label: "Cartes", emoji: "🃏" },
  { id: "quiz", label: "Quiz", emoji: "🎯" },
] as const;

type Dl = "idle" | "loading" | "done" | "error";

export default function CourseView({ initial }: { initial: Course }) {
  const [course, setCourse] = useState(initial);
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("audio");
  const [dl, setDl] = useState<Dl>("idle");
  const [dlPct, setDlPct] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const { record } = useProgress();

  useEffect(() => {
    fetchCourse(initial.id).then((c) => c && setCourse(c));
    try {
      if (localStorage.getItem(`offline:${initial.id}`)) setDl("done");
    } catch {}
  }, [initial.id]);

  const flash = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2600);
  };

  const download = async () => {
    setDl("loading");
    setDlPct(8);
    const timer = setInterval(() => setDlPct((p) => Math.min(92, p + 9)), 160);
    try {
      if ("caches" in window) {
        const cache = await caches.open("samacampus-offline");
        await cache.add(`/cours/${course.id}`).catch(() => {});
        if (course.audio_url) await cache.add(course.audio_url);
      }
      localStorage.setItem(`offline:${course.id}`, JSON.stringify(course));
      clearInterval(timer);
      setDlPct(100);
      setDl("done");
      flash("📥 Cours disponible hors-ligne !");
    } catch {
      clearInterval(timer);
      setDl("error");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Link href="/" className="grid h-10 w-10 place-items-center rounded-xl bg-white text-lg shadow-card active:scale-90">
          ←
        </Link>
        <div>
          <p className="text-xs font-black uppercase text-yello">{course.niveau} · {course.matiere}</p>
          <h1 className="text-2xl font-black leading-tight">{course.titre}</h1>
        </div>
      </div>

      {/* Onglets */}
      <div className="grid grid-cols-4 gap-1 rounded-2xl bg-yello/10 p-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative rounded-xl py-2 text-xs font-extrabold transition ${tab === t.id ? "text-yello-dark" : "text-ink/50"}`}
          >
            {tab === t.id && (
              <motion.span layoutId="tab-bg" className="absolute inset-0 rounded-xl bg-white shadow" transition={{ type: "spring", stiffness: 420, damping: 32 }} />
            )}
            <span className="relative block text-base">{t.emoji}</span>
            <span className="relative">{t.label}</span>
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.18 }}
        >
          {tab === "audio" && (
            <div className="space-y-3">
              <AudioPlayer
                titre={course.titre}
                emoji={course.emoji}
                text={course.resume}
                audioUrl={course.audio_url}
                durationMin={course.duree_min}
                onFinished={() => {
                  record({ xp: 15 });
                  flash("🎉 Cours écouté : +15 XP");
                }}
              />
              <p className="px-1 text-center text-xs font-semibold text-ink/50">
                💡 Astuce : écoute dans le bus, le tram ou en marchant vers la fac.
              </p>
            </div>
          )}
          {tab === "resume" && (
            <div className="card">
              <Resume text={course.resume} />
            </div>
          )}
          {tab === "cards" && (
            <FlashcardDeck
              cards={course.flashcards}
              onKnow={(k, n) => {
                if (k === n) {
                  record({ xp: 30 });
                  flash("🏅 Toutes les cartes maîtrisées : +30 XP");
                }
              }}
            />
          )}
          {tab === "quiz" && (
            <div className="card space-y-3 text-center">
              <div className="text-5xl">🎯</div>
              <h3 className="text-xl font-black">Quiz chrono · {course.quiz.length} questions</h3>
              <p className="text-sm font-semibold text-ink/60">20 secondes par question. Plus tu réponds vite, plus tu gagnes d'XP !</p>
              <Link href={`/quiz?course=${course.id}`} className="btn-pop w-full">
                ⚡ Lancer le quiz
              </Link>
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Hors-ligne */}
      <div className="card">
        <button
          onClick={download}
          disabled={dl === "loading" || dl === "done"}
          className={`w-full ${dl === "done" ? "btn-ghost !border-sn-green !text-sn-green" : "btn-green"}`}
        >
          {dl === "idle" && "⬇️ Télécharger pour hors-ligne"}
          {dl === "loading" && `⏳ Téléchargement… ${dlPct}%`}
          {dl === "done" && "✅ Disponible hors-ligne"}
          {dl === "error" && "⚠️ Échec — réessayer"}
        </button>
        {dl === "loading" && (
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-sn-green/15">
            <div className="h-full rounded-full bg-sn-green transition-all" style={{ width: `${dlPct}%` }} />
          </div>
        )}
        {dl === "error" && (
          <button onClick={download} className="mt-2 w-full text-sm font-bold text-sn-red">
            Réessayer
          </button>
        )}
      </div>

      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 40, opacity: 0 }}
            className="fixed bottom-24 left-1/2 z-50 -translate-x-1/2 rounded-2xl bg-ink px-4 py-3 text-sm font-extrabold text-white shadow-xl"
          >
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
