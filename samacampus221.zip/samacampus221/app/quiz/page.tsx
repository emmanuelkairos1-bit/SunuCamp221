import { Suspense } from "react";
import QuizClient from "./QuizClient";

export default function QuizPage() {
  return (
    <Suspense fallback={<p className="p-8 text-center text-4xl">⏳</p>}>
      <QuizClient />
    </Suspense>
  );
}
