"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { COURSES, QCM, localCourse, shuffle } from "@/lib/data";
import { BADGES, displayStreak, pushCourseProgress, useProgress } from "@/lib/progress";

const TIME = 20;
type Phase = "pick" | "play" | "result";
type Answer = { picked: number; points: number };

export default function QuizClient() {
  const params = useSearchParams();
  const { p, record } = useProgress();
  const [phase, setPhase] = useState<Phase>("pick");
  const [title, setTitle] = useState("");
  const [courseId, setCourseId] = useState<string | undefined>();
  const [qs, setQs] = useState<QCM[]>([]);
  const [idx, setIdx] = useState(0);
  const [left, setLeft] = useState(TIME);
  const [picked, setPicked] = useState<number | null>(null);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [result, setResult] = useState<{ xp: number; newBadges: string[]; streak: number; pct: number } | null>(null);
  const [hasGenerated, setHasGenerated] = useState(false);
  const started = useRef(false);

  const start = useCallback((questions: QCM[], t: string, cid?: string) => {
    if (!questions.length) return;
    setQs(questions);
    setTitle(t);
    setCourseId(cid);
    setIdx(0);
    setLeft(TIME);
    setPicked(null);
    setAnswers([]);
    setResult(null);
    setPhase("play");
  }, []);

  const startCourse = useCallback(
    (id: string) => {
      const c = localCourse(id);
      if (c) start(c.quiz, `${c.emoji} ${c.titre}`, c.id);
    },
    [start]
  );
  const startMix = useCallback(() => {
    const all = COURSES.flatMap((c) => c.quiz);
    start(shuffle(all).slice(0, 10), "🏛️ Mix concours", undefined);
  }, [start]);
  const startGenerated = useCallback(() => {
    try {
      const raw = sessionStorage.getItem("samacampus:generated-quiz");
      if (raw) start(JSON.parse(raw) as QCM[], "🤖 Ton quiz généré", undefined);
    } catch {}
  }, [start]);

  // Démarrage auto depuis les paramètres d'URL
  useEffect(() => {
    try {
      setHasGenerated(!!sessionStorage.getItem("samacampus:generated-quiz"));
    } catch {}
    if (started.current) return;
    started.current = true;
    const c = params.get("course");
    if (c) startCourse(c);
    else if (params.get("mix")) startMix();
    else if (params.get("source") === "generated") startGenerated();
  }, [params, startCourse, startMix, startGenerated]);

  const finish = useCallback(
    (all: Answer[]) => {
      const correct = all.filter((a, i) => a.picked === qs[i].answer).length;
      const pct = Math.round((correct / qs.length) * 100);
      const base = all.reduce((s, a) => s + a.points, 0);
      const bonus = pct === 100 ? 20 : 0;
      const xp = base + bonus;
      const { next, newBadges } = record({ xp, courseId, pct, quiz: true });
      if (courseId) pushCourseProgress(courseId, pct, xp, pct >= 60);
      setResult({ xp, newBadges, streak: displayStreak(next), pct });
      setPhase("result");
    },
    [qs, record, courseId]
  );

  const validate = useCallback(
    (choice: number, timeLeft: number) => {
      if (picked !== null) return;
      setPicked(choice);
      const ok = choice === qs[idx].answer;
      setAnswers((a) => [...a, { picked: choice, points: ok ? 10 + Math.max(0, timeLeft) : 0 }]);
    },
    [picked, qs, idx]
  );

  // Chrono
  useEffect(() => {
    if (phase !== "play" || picked !== null) return;
    if (left <= 0) {
      validate(-1, 0);
      return;
    }
    const t = setTimeout(() => setLeft((l) => l - 1), 1000);
    return () => clearTimeout(t);
  }, [phase, picked, left, validate]);

  const next = () => {
    if (idx + 1 >= qs.length) {
      finish(answers);
    } else {
      setIdx(idx + 1);
      setPicked(null);
      setLeft(TIME);
    }
  };

  /* ---------- PICK ---------- */
  if (phase === "pick") {
    return (
      <div className="space-y-4">
        <div>
          <h1 className="text-2xl font-black">🎯 Quiz chrono</h1>
          <p className="text-sm font-semibold text-ink/60">Style concours : {TIME} secondes par question, bonus de vitesse ⚡</p>
        </div>
        <div className="flex gap-2 text-sm font-extrabold">
          <span className="rounded-full bg-orange-100 px-3 py-1 text-orange-600">🔥 Série : {displayStreak(p)} jour{displayStreak(p) > 1 ? "s" : ""}</span>
          <span className="rounded-full bg-yello-soft px-3 py-1 text-yello-dark">⭐ {p.xp} XP</span>
        </div>
        <button onClick={startMix} className="btn-pop w-full !justify-between text-left">
          <span>🏛️ Mix concours (10 questions)</span>
          <span>➡️</span>
        </button>
        {hasGenerated && (
          <button onClick={startGenerated} className="btn-green w-full !justify-between">
            <span>🤖 Mon quiz généré par l'IA</span>
            <span>➡️</span>
          </button>
        )}
        <div className="space-y-2">
          {COURSES.map((c) => (
            <button key={c.id} onClick={() => startCourse(c.id)} className="card flex w-full items-center gap-3 !p-3 text-left active:scale-[0.98]">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-yello-soft text-2xl">{c.emoji}</span>
              <div className="flex-1">
                <p className="font-extrabold">{c.titre}</p>
                <p className="text-xs font-semibold text-ink/50">
                  {c.quiz.length} questions{p.best[c.id] !== undefined ? ` · meilleur score ${p.best[c.id]}%` : ""}
                </p>
              </div>
              <span className="text-yello">▶</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  /* ---------- RESULT ---------- */
  if (phase === "result" && result) {
    const correct = answers.filter((a, i) => a.picked === qs[i].answer).length;
    const emoji = result.pct === 100 ? "🏆" : result.pct >= 60 ? "🎉" : "💪";
    const msg = result.pct === 100 ? "Parfait ! Tu es une machine !" : result.pct >= 60 ? "Bravo, tu valides !" : "Courage, révise et réessaie !";
    return (
      <div className="space-y-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 14 }}
          className="rounded-3xl bg-gradient-to-br from-yello-dark to-yello p-6 text-center text-white shadow-card"
        >
          <motion.div animate={{ rotate: [0, -10, 10, 0] }} transition={{ repeat: 2, duration: 0.6 }} className="text-7xl">
            {emoji}
          </motion.div>
          <p className="mt-2 text-lg font-black">{msg}</p>
          <p className="text-5xl font-black">
            {correct}/{qs.length}
          </p>
          <p className="text-sm font-bold text-white/80">{title}</p>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <div className="rounded-2xl bg-white/20 p-3">
              <p className="text-2xl font-black">+{result.xp}</p>
              <p className="text-xs font-bold">⭐ XP gagnés</p>
            </div>
            <div className="rounded-2xl bg-white/20 p-3">
              <p className="text-2xl font-black">🔥 {result.streak}</p>
              <p className="text-xs font-bold">jour{result.streak > 1 ? "s" : ""} de suite</p>
            </div>
          </div>
        </motion.div>

        {result.newBadges.length > 0 && (
          <div className="card border-2 border-sn-yellow">
            <p className="font-black">🎖️ Nouveau badge !</p>
            {result.newBadges.map((id) => {
              const b = BADGES.find((x) => x.id === id)!;
              return (
                <p key={id} className="font-bold">
                  {b.emoji} {b.nom} <span className="text-sm text-ink/50">— {b.desc}</span>
                </p>
              );
            })}
          </div>
        )}

        <h2 className="text-lg font-black">📖 Corrigé</h2>
        <div className="space-y-2">
          {qs.map((q, i) => {
            const a = answers[i];
            const ok = a?.picked === q.answer;
            return (
              <div key={i} className={`card !p-3 border-l-4 ${ok ? "border-sn-green" : "border-sn-red"}`}>
                <p className="font-extrabold">
                  {ok ? "✅" : a?.picked === -1 ? "⏰" : "❌"} {q.q}
                </p>
                {!ok && <p className="text-sm font-bold text-sn-red">Ta réponse : {a?.picked >= 0 ? q.options[a.picked] : "temps écoulé"}</p>}
                <p className="text-sm font-bold text-sn-green">Bonne réponse : {q.options[q.answer]}</p>
                <p className="mt-1 text-sm text-ink/70">💡 {q.explication}</p>
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button className="btn-pop" onClick={() => start(qs, title, courseId)}>
            🔁 Rejouer
          </button>
          <Link href="/leaderboard" className="btn-green">
            🏆 Classement
          </Link>
        </div>
        <button className="btn-ghost w-full" onClick={() => setPhase("pick")}>
          Choisir un autre quiz
        </button>
      </div>
    );
  }

  /* ---------- PLAY ---------- */
  const q = qs[idx];
  if (!q) return null;
  const lastPoints = answers[idx]?.points ?? 0;
  const danger = left <= 5;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-sm font-extrabold">
        <span className="text-yello-dark">{title}</span>
        <span>
          Question {idx + 1}/{qs.length}
        </span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-yello/15">
        <div className="h-full rounded-full bg-sn-green transition-all" style={{ width: `${(idx / qs.length) * 100}%` }} />
      </div>

      <div className="flex items-center gap-3">
        <motion.div
          animate={danger && picked === null ? { scale: [1, 1.15, 1] } : {}}
          transition={{ repeat: Infinity, duration: 0.8 }}
          className={`grid h-14 w-14 shrink-0 place-items-center rounded-full text-xl font-black text-white ${danger ? "bg-sn-red" : "bg-yello"}`}
        >
          {left}
        </motion.div>
        <div className="h-3 flex-1 overflow-hidden rounded-full bg-yello/15">
          <div
            className={`h-full rounded-full transition-all duration-1000 ease-linear ${danger ? "bg-sn-red" : "bg-yello"}`}
            style={{ width: `${(left / TIME) * 100}%` }}
          />
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={idx} initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }} className="space-y-3">
          <div className="card text-lg font-extrabold leading-snug">{q.q}</div>
          {q.options.map((o, i) => {
            const isRight = i === q.answer;
            const state =
              picked === null
                ? "border-yello/20 bg-white"
                : isRight
                ? "border-sn-green bg-green-50"
                : i === picked
                ? "border-sn-red bg-red-50"
                : "border-transparent bg-white opacity-60";
            return (
              <motion.button
                key={i}
                whileTap={{ scale: picked === null ? 0.97 : 1 }}
                animate={picked !== null && i === picked && !isRight ? { x: [0, -8, 8, -6, 6, 0] } : {}}
                disabled={picked !== null}
                onClick={() => validate(i, left)}
                className={`flex w-full items-center gap-3 rounded-2xl border-2 p-3.5 text-left font-bold shadow-sm ${state}`}
              >
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-yello-soft text-sm font-black text-yello-dark">
                  {"ABCD"[i]}
                </span>
                <span className="flex-1">{o}</span>
                {picked !== null && isRight && <span>✅</span>}
                {picked !== null && i === picked && !isRight && <span>❌</span>}
              </motion.button>
            );
          })}
        </motion.div>
      </AnimatePresence>

      {picked !== null && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
          <div className={`rounded-2xl p-3 text-sm font-bold ${picked === q.answer ? "bg-green-100 text-green-900" : "bg-red-100 text-red-900"}`}>
            {picked === q.answer ? `🎉 Bonne réponse ! +${lastPoints} XP` : picked === -1 ? "⏰ Temps écoulé !" : "😅 Raté !"}
            <p className="mt-1 font-semibold">💡 {q.explication}</p>
          </div>
          <button className="btn-pop w-full" onClick={next}>
            {idx + 1 >= qs.length ? "🏁 Voir mon score" : "Question suivante ➡️"}
          </button>
        </motion.div>
      )}
    </div>
  );
}
