import { COURSES, Flashcard, QCM, shuffle } from "./data";

export type Generated = {
  topic: string;
  topicLabel: string;
  flashcards: Flashcard[];
  qcm: QCM[];
  fromText: number; // nb de cartes issues directement du texte collé
};

const STOP = new Set(
  (
    "alors aussi autre avant avec avoir cette cependant chaque comme dans depuis donc elle elles encore entre était être fait faire " +
    "leur leurs mais même moins notre nous parce pendant plus pour pourquoi quand sans selon sont sous tout tous toute toutes très " +
    "votre vous ainsi ceux celle celui ces cela dont lorsque puis sera seront peut peuvent permet doit doivent après contre vers"
  ).split(" ")
);

const TOPICS: Record<string, string[]> = {
  "algo-l1": ["algorithme", "boucle", "tableau", "variable", "tri ", "complexité", "itération", "pseudo-code"],
  "prog-c": ["pointeur", "printf", "scanf", "langage c", "#include", "compil", "malloc", "int "],
  "droit-constit": ["constitution", "pouvoir", "assemblée", "président", "juridique", "conseil constitutionnel", "droit", "loi "],
  "compta-generale": ["bilan", "comptab", "débit", "crédit", "actif", "passif", "charge", "produit", "syscohada"],
  "anglais-l1": [" the ", "english", "verb", "tense", " is ", " are ", "present", "past simple"],
  "microeco-l1": ["marché", "prix", "offre", "demande", "élasticité", "consommateur", "économ", "utilité"],
};

export function detectTopic(text: string): string | null {
  const t = ` ${text.toLowerCase()} `;
  let best: string | null = null;
  let bestScore = 0;
  for (const [id, kws] of Object.entries(TOPICS)) {
    const score = kws.reduce((s, k) => s + (t.split(k).length - 1), 0);
    if (score > bestScore) {
      best = id;
      bestScore = score;
    }
  }
  return best;
}

function hash(s: string) {
  let h = 1779033703 ^ s.length;
  for (let i = 0; i < s.length; i++) {
    h = Math.imul(h ^ s.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return h >>> 0;
}
function rng(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
const noArticle = (s: string) => s.replace(/^(le|la|les|l'|l’|un|une|des|du|de la)\s*/i, "").trim();

function sentencesOf(text: string) {
  return text
    .split(/\n+/)
    .flatMap((l) => l.replace(/\s+/g, " ").split(/(?<=[.!?])\s+/))
    .map((s) => s.trim().replace(/^[-•*\d.)\s]+/, ""))
    .filter((s) => s.length >= 25 && s.length <= 240);
}

function keywordOf(sentence: string): string | null {
  const words = sentence.match(/[A-Za-zÀ-ÿ'’-]{6,}/g) ?? [];
  const cands = words
    .map((w) => w.replace(/^['’-]+|['’-]+$/g, ""))
    .filter((w) => w.length >= 6 && !STOP.has(w.toLowerCase()));
  if (!cands.length) return null;
  return cands.sort((a, b) => b.length - a.length)[0];
}

const DEF = /^([^,;:.]{3,60}?)\s+(est|sont|désigne|signifie|correspond à|représente|permet de|consiste à)\s+(.{12,})$/i;

function toFlashcard(s: string): Flashcard | null {
  const m = s.match(DEF);
  if (m) {
    const subj = noArticle(m[1]);
    const verb = m[2].toLowerCase();
    const answer = cap(s.replace(/[.!]+$/, "")) + ".";
    if (verb === "permet de") return { q: `À quoi sert ${subj} ?`, a: answer };
    if (verb === "consiste à") return { q: `En quoi consiste ${subj} ?`, a: answer };
    return { q: `Définis : ${subj}`, a: answer };
  }
  const kw = keywordOf(s);
  if (!kw) return null;
  return { q: `Complète : ${s.replace(kw, "_____")}`, a: `${kw} — ${s}` };
}

export function generate(text: string): Generated {
  const clean = text.trim();
  const topic = detectTopic(clean);
  const sents = sentencesOf(clean);
  const seed = hash(clean);
  const rnd = rng(seed);

  // 1) Flashcards issues du texte collé
  const flashcards: Flashcard[] = [];
  const seenQ = new Set<string>();
  for (const s of sents) {
    const f = toFlashcard(s);
    if (f && !seenQ.has(f.q)) {
      flashcards.push(f);
      seenQ.add(f.q);
    }
    if (flashcards.length >= 10) break;
  }
  const fromText = flashcards.length;

  // 2) Complétion avec la banque de cartes du cours le plus proche
  const bank = topic
    ? [COURSES.find((c) => c.id === topic)!, ...COURSES.filter((c) => c.id !== topic)]
    : COURSES;
  for (const c of bank) {
    for (const f of c.flashcards) {
      if (flashcards.length >= 10) break;
      if (!seenQ.has(f.q)) {
        flashcards.push(f);
        seenQ.add(f.q);
      }
    }
    if (flashcards.length >= 10) break;
  }

  // 3) QCM : phrases à trous du texte (en partant de la fin pour varier), distracteurs = autres mots-clés
  const keywords = Array.from(
    new Set(sents.map(keywordOf).filter((k): k is string => !!k).map((k) => k.toLowerCase()))
  );
  const topicWords = topic
    ? Array.from(
        new Set(
          (COURSES.find((c) => c.id === topic)!.resume.match(/[A-Za-zÀ-ÿ]{7,}/g) ?? []).map((w) => w.toLowerCase())
        )
      ).filter((w) => !STOP.has(w))
    : [];

  const qcm: QCM[] = [];
  for (const s of [...sents].reverse()) {
    if (qcm.length >= 5) break;
    const kw = keywordOf(s);
    if (!kw) continue;
    const pool = Array.from(new Set([...keywords, ...topicWords])).filter((k) => k !== kw.toLowerCase());
    if (pool.length < 3) continue;
    const distractors = shuffle(pool, rnd).slice(0, 3);
    const options = shuffle([kw.toLowerCase(), ...distractors], rnd);
    qcm.push({
      q: `Complète : ${s.replace(kw, "_____")}`,
      options: options.map(cap),
      answer: options.indexOf(kw.toLowerCase()),
      explication: `Réponse : « ${kw} ». ${s}`,
    });
  }
  // Complétion avec les QCM du cours le plus proche
  for (const c of bank) {
    for (const q of c.quiz) {
      if (qcm.length >= 5) break;
      if (!qcm.some((x) => x.q === q.q)) qcm.push(q);
    }
    if (qcm.length >= 5) break;
  }

  const t = topic ? COURSES.find((c) => c.id === topic)! : null;
  return {
    topic: topic ?? "general",
    topicLabel: t ? `${t.emoji} ${t.titre}` : "📚 Culture générale",
    flashcards: flashcards.slice(0, 10),
    qcm: qcm.slice(0, 5),
    fromText,
  };
}

export const SAMPLE_TEXT = `La séparation des pouvoirs est un principe fondamental de l'État de droit. Montesquieu est le théoricien de la séparation des pouvoirs dans son ouvrage L'Esprit des lois. Le pouvoir législatif correspond à l'Assemblée nationale qui vote les lois. Le pouvoir exécutif est exercé par le Président de la République et le Gouvernement. Le pouvoir judiciaire est confié aux juges et aux tribunaux. La Constitution est la norme suprême de l'État. Le Conseil constitutionnel contrôle la conformité des lois à la Constitution. La hiérarchie des normes place la Constitution au sommet, suivie des traités, des lois et des règlements. Le référendum permet au peuple de se prononcer directement sur un texte. Le pouvoir constituant dérivé consiste à réviser la Constitution selon la procédure prévue.`;
