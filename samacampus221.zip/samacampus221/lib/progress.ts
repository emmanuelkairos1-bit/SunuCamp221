"use client";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "./supabase";

export type Progress = {
  xp: number;
  streak: number;
  lastDay: string | null;
  badges: string[];
  quizzes: number;
  pseudo: string;
  uni: string;
  best: Record<string, number>; // meilleur % par cours
};

export const BADGES = [
  { id: "leve-tot", emoji: "🌅", nom: "Lève-tôt", desc: "Révise avant 8h du matin" },
  { id: "couche-tard", emoji: "🦉", nom: "Couche-tard", desc: "Révise après 22h" },
  { id: "100-algo", emoji: "🧮", nom: "100% Algo", desc: "Score parfait au quiz Algorithmique" },
  { id: "serie-3", emoji: "🔥", nom: "Série de 3", desc: "3 jours de suite" },
  { id: "serie-7", emoji: "⚡", nom: "Série de 7", desc: "7 jours de suite" },
  { id: "quiz-master", emoji: "🏆", nom: "Quiz Master", desc: "10 quiz terminés" },
];

const KEY = "samacampus:progress:v1";
const EVT = "samacampus:progress";

export const DEFAULT_PROGRESS: Progress = {
  xp: 0,
  streak: 0,
  lastDay: null,
  badges: [],
  quizzes: 0,
  pseudo: "Toi",
  uni: "UCAD",
  best: {},
};

export function dayKey(d = new Date()) {
  return d.toLocaleDateString("sv-SE"); // YYYY-MM-DD (heure locale)
}

export function load(): Progress {
  try {
    const s = localStorage.getItem(KEY);
    return s ? { ...DEFAULT_PROGRESS, ...JSON.parse(s) } : DEFAULT_PROGRESS;
  } catch {
    return DEFAULT_PROGRESS;
  }
}

function save(p: Progress) {
  try {
    localStorage.setItem(KEY, JSON.stringify(p));
    window.dispatchEvent(new Event(EVT));
  } catch {}
}

/** Série affichée : retombe à 0 si l'étudiant a raté hier. */
export function displayStreak(p: Progress) {
  if (!p.lastDay) return 0;
  const today = dayKey();
  const yest = dayKey(new Date(Date.now() - 86400000));
  return p.lastDay === today || p.lastDay === yest ? p.streak : 0;
}

export function levelOf(xp: number) {
  const level = Math.floor(xp / 200) + 1;
  return { level, into: xp % 200, next: 200 };
}

type Activity = { xp: number; courseId?: string; pct?: number; quiz?: boolean };

export function applyActivity(p: Progress, a: Activity) {
  const now = new Date();
  const today = dayKey(now);
  const yest = dayKey(new Date(now.getTime() - 86400000));
  let streak = p.streak;
  if (p.lastDay !== today) streak = p.lastDay === yest ? p.streak + 1 : 1;

  const next: Progress = {
    ...p,
    xp: p.xp + a.xp,
    streak,
    lastDay: today,
    quizzes: p.quizzes + (a.quiz ? 1 : 0),
    best: { ...p.best },
    badges: [...p.badges],
  };
  if (a.courseId && a.pct !== undefined) {
    next.best[a.courseId] = Math.max(next.best[a.courseId] ?? 0, a.pct);
  }

  const h = now.getHours();
  const earned: string[] = [];
  if (h >= 4 && h < 8) earned.push("leve-tot");
  if (h >= 22 || h < 4) earned.push("couche-tard");
  if (a.quiz && a.courseId === "algo-l1" && a.pct === 100) earned.push("100-algo");
  if (streak >= 3) earned.push("serie-3");
  if (streak >= 7) earned.push("serie-7");
  if (next.quizzes >= 10) earned.push("quiz-master");

  const newBadges = earned.filter((b) => !next.badges.includes(b));
  next.badges.push(...newBadges);
  return { next, newBadges };
}

async function pushRemote(p: Progress) {
  if (!supabase) return;
  try {
    const { data } = await supabase.auth.getSession();
    const uid = data.session?.user.id;
    if (!uid) return;
    await supabase.from("users").upsert({
      id: uid,
      pseudo: p.pseudo,
      universite: p.uni,
      xp: p.xp,
      streak: p.streak,
      last_active: p.lastDay,
      badges: p.badges,
    });
  } catch {}
}

export async function pushCourseProgress(courseId: string, score: number, xp: number, completed: boolean) {
  if (!supabase) return;
  try {
    const { data } = await supabase.auth.getSession();
    const uid = data.session?.user.id;
    if (!uid) return;
    await supabase
      .from("user_progress")
      .upsert(
        { user_id: uid, course_id: courseId, quiz_score: score, xp, completed, updated_at: new Date().toISOString() },
        { onConflict: "user_id,course_id" }
      );
  } catch {}
}

export function useProgress() {
  const [p, setP] = useState<Progress>(DEFAULT_PROGRESS);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const sync = () => setP(load());
    sync();
    setReady(true);
    window.addEventListener(EVT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const record = useCallback((a: Activity) => {
    const { next, newBadges } = applyActivity(load(), a);
    save(next);
    pushRemote(next);
    return { next, newBadges };
  }, []);

  const update = useCallback((patch: Partial<Progress>) => {
    const next = { ...load(), ...patch };
    save(next);
    pushRemote(next);
  }, []);

  return { p, ready, record, update };
}
