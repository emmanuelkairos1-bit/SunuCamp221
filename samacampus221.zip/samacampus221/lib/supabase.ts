import { createClient, SupabaseClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

/** null si Supabase n'est pas configuré : l'app fonctionne alors en mode démo (données locales). */
export const supabase: SupabaseClient | null =
  url && key && !url.includes("xxxxxxxx") ? createClient(url, key) : null;

export const hasSupabase = !!supabase;
