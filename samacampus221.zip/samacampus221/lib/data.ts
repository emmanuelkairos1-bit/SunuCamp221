import raw from "@/data/courses.json";
import { supabase } from "./supabase";

export type Flashcard = { q: string; a: string };
export type QCM = { q: string; options: string[]; answer: number; explication: string };
export type Course = {
  id: string;
  titre: string;
  niveau: string;
  matiere: string;
  emoji: string;
  duree_min: number;
  audio_url: string | null;
  resume: string;
  flashcards: Flashcard[];
  quiz: QCM[];
};

export const COURSES = raw as Course[];

export const MATIERES = [
  { id: "droit", label: "L1 Droit", emoji: "⚖️", first: "droit-constit", color: "from-yello to-yello-light" },
  { id: "informatique", label: "L1 Informatique", emoji: "💻", first: "algo-l1", color: "from-sn-green to-sn-lime" },
  { id: "eco", label: "L1 Éco", emoji: "📈", first: "compta-generale", color: "from-amber-400 to-sn-yellow" },
  { id: "ena", label: "Concours ENA", emoji: "🏛️", first: "anglais-l1", color: "from-sn-red to-orange-400" },
];

export function localCourse(id: string): Course | undefined {
  return COURSES.find((c) => c.id === id);
}

/** Récupère un cours depuis Supabase si dispo, sinon depuis les données locales. */
export async function fetchCourse(id: string): Promise<Course | undefined> {
  const local = localCourse(id);
  if (!supabase) return local;
  try {
    const { data: c } = await supabase.from("courses").select("*").eq("id", id).single();
    if (!c) return local;
    const [{ data: f }, { data: q }] = await Promise.all([
      supabase.from("flashcards").select("question, reponse").eq("course_id", id).order("id"),
      supabase.from("quiz_questions").select("*").eq("course_id", id).order("id"),
    ]);
    return {
      id: c.id,
      titre: c.titre,
      niveau: c.niveau,
      matiere: c.matiere ?? local?.matiere ?? "",
      emoji: c.emoji ?? local?.emoji ?? "📚",
      duree_min: c.duree_min ?? local?.duree_min ?? 15,
      audio_url: c.audio_url,
      resume: c.resume,
      flashcards: f?.length ? f.map((x) => ({ q: x.question, a: x.reponse })) : local?.flashcards ?? [],
      quiz: q?.length
        ? q.map((x) => ({
            q: x.question,
            options: x.options,
            answer: x.bonne_reponse,
            explication: x.explication ?? "",
          }))
        : local?.quiz ?? [],
    };
  } catch {
    return local;
  }
}

export const UNIVERSITES = [
  { id: "UCAD", nom: "UCAD", ville: "Dakar", emoji: "🦁" },
  { id: "UGB", nom: "UGB", ville: "Saint-Louis", emoji: "🌊" },
  { id: "UVS", nom: "UVS", ville: "Campus virtuel", emoji: "🌐" },
  { id: "UADB", nom: "Bambey", ville: "Bambey", emoji: "🌾" },
];

export function shuffle<T>(arr: T[], rnd: () => number = Math.random): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
