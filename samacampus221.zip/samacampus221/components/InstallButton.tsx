"use client";
import { useEffect, useState } from "react";

type BIPEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };

export default function InstallButton() {
  const [evt, setEvt] = useState<BIPEvent | null>(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setEvt(e as BIPEvent);
    };
    const onInstalled = () => setDone(true);
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  if (done) return <p className="text-center text-sm font-bold text-sn-green">✅ App installée !</p>;
  if (!evt) return null;
  return (
    <button
      className="btn-green w-full"
      onClick={async () => {
        await evt.prompt();
        const c = await evt.userChoice;
        if (c.outcome === "accepted") setDone(true);
        setEvt(null);
      }}
    >
      📲 Installer SamaCampus sur mon téléphone
    </button>
  );
}
