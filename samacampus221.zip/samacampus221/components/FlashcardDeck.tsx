"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import type { Flashcard } from "@/lib/data";

export default function FlashcardDeck({
  cards,
  onKnow,
}: {
  cards: Flashcard[];
  onKnow?: (known: number, total: number) => void;
}) {
  const [i, setI] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [dir, setDir] = useState(1);
  const [known, setKnown] = useState<Set<number>>(new Set());
  const [review, setReview] = useState<Set<number>>(new Set());

  const go = (n: number) => {
    setDir(n > i ? 1 : -1);
    setFlipped(false);
    setI(Math.max(0, Math.min(cards.length - 1, n)));
  };

  const mark = (ok: boolean) => {
    const k = new Set(known);
    const r = new Set(review);
    if (ok) {
      k.add(i);
      r.delete(i);
    } else {
      r.add(i);
      k.delete(i);
    }
    setKnown(k);
    setReview(r);
    onKnow?.(k.size, cards.length);
    if (i < cards.length - 1) go(i + 1);
  };

  const c = cards[i];
  if (!c) return null;

  return (
    <div>
      <div className="mb-2 flex items-center justify-between text-sm font-extrabold">
        <span className="text-yello-dark">
          🃏 Carte {i + 1}/{cards.length}
        </span>
        <span className="text-sn-green">✅ {known.size} sues</span>
      </div>
      <div className="mb-3 h-2 overflow-hidden rounded-full bg-yello/15">
        <motion.div
          className="h-full rounded-full bg-gradient-to-r from-yello to-sn-green"
          animate={{ width: `${((i + 1) / cards.length) * 100}%` }}
        />
      </div>

      <AnimatePresence mode="wait" custom={dir}>
        <motion.div
          key={i}
          custom={dir}
          initial={{ x: dir * 60, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -dir * 60, opacity: 0 }}
          transition={{ duration: 0.18 }}
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={0.4}
          onDragEnd={(_, info) => {
            if (info.offset.x < -70) go(i + 1);
            else if (info.offset.x > 70) go(i - 1);
          }}
          className="perspective"
        >
          <motion.button
            type="button"
            onClick={() => setFlipped((f) => !f)}
            animate={{ rotateY: flipped ? 180 : 0 }}
            transition={{ type: "spring", stiffness: 220, damping: 22 }}
            className="preserve-3d relative block h-72 w-full text-left"
          >
            <div className="backface-hidden absolute inset-0 flex flex-col justify-between rounded-3xl bg-gradient-to-br from-yello to-yello-light p-6 text-white shadow-card">
              <span className="text-xs font-black uppercase tracking-wider text-white/80">❓ Question</span>
              <p className="text-xl font-extrabold leading-snug">{c.q}</p>
              <span className="text-sm font-bold text-white/80">👆 Touche pour retourner</span>
            </div>
            <div
              className="backface-hidden absolute inset-0 flex flex-col justify-between rounded-3xl bg-gradient-to-br from-sn-green to-sn-lime p-6 text-white shadow-card"
              style={{ transform: "rotateY(180deg)" }}
            >
              <span className="text-xs font-black uppercase tracking-wider text-white/80">💡 Réponse</span>
              <p className="text-lg font-bold leading-snug">{c.a}</p>
              <span className="text-sm font-bold text-white/80">Tu la savais ?</span>
            </div>
          </motion.button>
        </motion.div>
      </AnimatePresence>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <button className="btn-ghost" onClick={() => mark(false)}>
          😅 À revoir
        </button>
        <button className="btn-green" onClick={() => mark(true)}>
          💪 Je sais !
        </button>
      </div>
      <div className="mt-3 flex items-center justify-between">
        <button className="rounded-xl px-3 py-2 text-sm font-bold text-ink/60 disabled:opacity-30" disabled={i === 0} onClick={() => go(i - 1)}>
          ← Précédente
        </button>
        <div className="flex gap-1">
          {cards.map((_, k) => (
            <span
              key={k}
              className={`h-2 w-2 rounded-full ${
                k === i ? "bg-yello" : known.has(k) ? "bg-sn-green" : review.has(k) ? "bg-sn-red/70" : "bg-yello/20"
              }`}
            />
          ))}
        </div>
        <button className="rounded-xl px-3 py-2 text-sm font-bold text-ink/60 disabled:opacity-30" disabled={i === cards.length - 1} onClick={() => go(i + 1)}>
          Suivante →
        </button>
      </div>
    </div>
  );
}
