/** Rendu minimal du résumé : "## titre", "- puces", paragraphes. */
export default function Resume({ text }: { text: string }) {
  const lines = text.split("\n");
  return (
    <div className="space-y-2 text-[15px] leading-relaxed">
      {lines.map((l, i) => {
        if (l.startsWith("## "))
          return (
            <h3 key={i} className="pt-2 text-lg font-black text-yello-dark">
              📌 {l.slice(3)}
            </h3>
          );
        if (l.startsWith("- "))
          return (
            <p key={i} className="flex gap-2">
              <span className="text-sn-green">●</span>
              <span>{l.slice(2)}</span>
            </p>
          );
        return <p key={i}>{l}</p>;
      })}
    </div>
  );
}
