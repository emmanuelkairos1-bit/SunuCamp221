"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";

/** Lecteur audio : fichier MP3 si `audioUrl` existe, sinon lecture vocale du résumé (voix du navigateur, fr-FR). */
export default function AudioPlayer({
  titre,
  emoji,
  text,
  audioUrl,
  durationMin,
  onFinished,
}: {
  titre: string;
  emoji: string;
  text: string;
  audioUrl: string | null;
  durationMin: number;
  onFinished?: () => void;
}) {
  const plain = text.replace(/^## /gm, "").replace(/^- /gm, "").replace(/\n+/g, ". ");
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0); // 0..1
  const [speed, setSpeed] = useState(1);
  const [total, setTotal] = useState(durationMin * 60);
  const offsetRef = useRef(0);
  const speedRef = useRef(1);
  const finishedRef = useRef(false);

  const finish = useCallback(() => {
    setPlaying(false);
    setProgress(1);
    if (!finishedRef.current) {
      finishedRef.current = true;
      onFinished?.();
    }
  }, [onFinished]);

  const speakFrom = useCallback(
    (charIdx: number) => {
      const synth = window.speechSynthesis;
      if (!synth) return;
      synth.cancel();
      const slice = plain.slice(charIdx);
      const u = new SpeechSynthesisUtterance(slice);
      u.lang = "fr-FR";
      u.rate = speedRef.current;
      offsetRef.current = charIdx;
      u.onboundary = (e) => setProgress((charIdx + e.charIndex) / plain.length);
      u.onend = () => finish();
      u.onerror = () => setPlaying(false);
      synth.speak(u);
      setPlaying(true);
    },
    [plain, finish]
  );

  useEffect(() => {
    return () => {
      if (typeof window !== "undefined") window.speechSynthesis?.cancel();
    };
  }, []);

  const toggle = () => {
    if (audioUrl) {
      const a = audioRef.current;
      if (!a) return;
      if (a.paused) a.play();
      else a.pause();
      return;
    }
    const synth = window.speechSynthesis;
    if (!synth) return alert("La lecture vocale n'est pas supportée par ce navigateur.");
    if (playing) {
      synth.pause();
      setPlaying(false);
    } else if (synth.paused) {
      synth.resume();
      setPlaying(true);
    } else {
      speakFrom(progress >= 0.99 ? 0 : Math.floor(progress * plain.length));
    }
  };

  const seekTo = (ratio: number) => {
    const r = Math.max(0, Math.min(1, ratio));
    setProgress(r);
    if (audioUrl) {
      const a = audioRef.current;
      if (a && a.duration) a.currentTime = r * a.duration;
    } else if (playing || window.speechSynthesis?.paused) {
      speakFrom(Math.floor(r * plain.length));
    }
  };

  const skip = (sec: number) => seekTo(progress + sec / total);

  const changeSpeed = () => {
    const order = [1, 1.25, 1.5, 0.75];
    const nx = order[(order.indexOf(speed) + 1) % order.length];
    setSpeed(nx);
    speedRef.current = nx;
    if (audioUrl && audioRef.current) audioRef.current.playbackRate = nx;
    else if (playing) speakFrom(Math.floor(progress * plain.length));
  };

  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

  return (
    <div className="overflow-hidden rounded-3xl bg-gradient-to-br from-yello-dark via-yello to-yello-light p-5 text-white shadow-card">
      {audioUrl && (
        <audio
          ref={audioRef}
          src={audioUrl}
          preload="metadata"
          onLoadedMetadata={(e) => setTotal(e.currentTarget.duration)}
          onTimeUpdate={(e) => setProgress(e.currentTarget.currentTime / (e.currentTarget.duration || 1))}
          onPlay={() => setPlaying(true)}
          onPause={() => setPlaying(false)}
          onEnded={finish}
        />
      )}
      <div className="flex items-center gap-4">
        <motion.div
          animate={playing ? { rotate: [0, -6, 6, 0] } : { rotate: 0 }}
          transition={{ repeat: playing ? Infinity : 0, duration: 1.6 }}
          className="grid h-20 w-20 shrink-0 place-items-center rounded-2xl bg-white/20 text-5xl"
        >
          {emoji}
        </motion.div>
        <div className="min-w-0">
          <p className="text-xs font-black uppercase tracking-wider text-white/70">🎧 Cours audio</p>
          <h2 className="truncate text-xl font-black">{titre}</h2>
          <p className="text-sm font-semibold text-white/80">{durationMin} min · {audioUrl ? "MP3" : "Voix IA 🇸🇳"}</p>
        </div>
      </div>

      <div className="mt-5 flex h-8 items-end justify-center gap-1">
        {Array.from({ length: 24 }).map((_, i) => (
          <motion.span
            key={i}
            className="w-1.5 rounded-full bg-white/70"
            animate={{ height: playing ? [6, 10 + ((i * 7) % 22), 6] : 6 }}
            transition={{ repeat: playing ? Infinity : 0, duration: 0.7 + (i % 5) * 0.12, delay: i * 0.03 }}
          />
        ))}
      </div>

      <div
        className="mt-4 h-3 cursor-pointer overflow-hidden rounded-full bg-white/25"
        onClick={(e) => {
          const r = e.currentTarget.getBoundingClientRect();
          seekTo((e.clientX - r.left) / r.width);
        }}
        role="slider"
        aria-valuenow={Math.round(progress * 100)}
        aria-label="Progression"
      >
        <div className="h-full rounded-full bg-sn-yellow" style={{ width: `${progress * 100}%` }} />
      </div>
      <div className="mt-1 flex justify-between text-xs font-bold text-white/80">
        <span>{fmt(progress * total)}</span>
        <span>{fmt(total)}</span>
      </div>

      <div className="mt-3 flex items-center justify-between">
        <button onClick={changeSpeed} className="w-14 rounded-xl bg-white/20 py-2 text-sm font-black active:scale-95">
          {speed}x
        </button>
        <div className="flex items-center gap-3">
          <button onClick={() => skip(-10)} className="grid h-11 w-11 place-items-center rounded-full bg-white/20 text-lg font-black active:scale-90" aria-label="Reculer de 10 secondes">
            ⏪
          </button>
          <button
            onClick={toggle}
            className="grid h-16 w-16 place-items-center rounded-full bg-white text-3xl text-yello shadow-lg active:scale-90"
            aria-label={playing ? "Pause" : "Lecture"}
          >
            {playing ? "⏸" : "▶️"}
          </button>
          <button onClick={() => skip(10)} className="grid h-11 w-11 place-items-center rounded-full bg-white/20 text-lg font-black active:scale-90" aria-label="Avancer de 10 secondes">
            ⏩
          </button>
        </div>
        <span className="w-14 text-right text-xs font-bold text-white/80">{Math.round(progress * 100)}%</span>
      </div>
    </div>
  );
}
