"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";

const ITEMS = [
  { href: "/", emoji: "🏠", label: "Accueil" },
  { href: "/generate", emoji: "🤖", label: "IA" },
  { href: "/quiz", emoji: "🎯", label: "Quiz" },
  { href: "/leaderboard", emoji: "🏆", label: "Top" },
  { href: "/login", emoji: "👤", label: "Profil" },
];

export default function BottomNav() {
  const path = usePathname();
  return (
    <nav className="fixed bottom-0 left-1/2 z-40 w-full max-w-md -translate-x-1/2 border-t border-yello/10 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur">
      <ul className="grid grid-cols-5">
        {ITEMS.map((it) => {
          const active = it.href === "/" ? path === "/" : path.startsWith(it.href);
          return (
            <li key={it.href}>
              <Link href={it.href} className="relative flex flex-col items-center gap-0.5 py-2 text-[11px] font-bold">
                {active && (
                  <motion.span
                    layoutId="nav-pill"
                    className="absolute inset-x-3 top-1 h-9 rounded-2xl bg-yello-soft"
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  />
                )}
                <span className="relative text-xl">{it.emoji}</span>
                <span className={`relative ${active ? "text-yello-dark" : "text-ink/50"}`}>{it.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
