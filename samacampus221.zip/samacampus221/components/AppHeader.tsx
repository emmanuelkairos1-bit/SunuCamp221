"use client";
import Link from "next/link";
import { displayStreak, levelOf, useProgress } from "@/lib/progress";

export default function AppHeader() {
  const { p, ready } = useProgress();
  const streak = ready ? displayStreak(p) : 0;
  const { level } = levelOf(p.xp);
  return (
    <header className="sticky top-0 z-30 border-b border-yello/10 bg-white/90 px-4 pb-2 pt-[max(0.6rem,env(safe-area-inset-top))] backdrop-blur">
      <div className="flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-black text-ink">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-yello text-lg shadow-pop">🎓</span>
          <span className="leading-tight">
            SamaCampus <span className="text-sn-green">221</span>
          </span>
        </Link>
        <div className="flex items-center gap-1.5 text-sm font-extrabold">
          <span className="rounded-full bg-orange-100 px-2.5 py-1 text-orange-600">🔥 {streak}</span>
          <span className="rounded-full bg-yello-soft px-2.5 py-1 text-yello-dark">⭐ {p.xp}</span>
          <span className="rounded-full bg-green-100 px-2.5 py-1 text-sn-green">Niv.{level}</span>
        </div>
      </div>
      <div className="mt-2 flex h-1 overflow-hidden rounded-full">
        <div className="flex-1 bg-sn-green" />
        <div className="flex-1 bg-sn-yellow" />
        <div className="flex-1 bg-sn-red" />
      </div>
    </header>
  );
}
