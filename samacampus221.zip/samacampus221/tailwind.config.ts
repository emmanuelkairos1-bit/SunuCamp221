import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        yello: {
          DEFAULT: "#6C5CE7",
          dark: "#4B3FC4",
          light: "#A29BFE",
          soft: "#F1EFFF",
        },
        sn: {
          green: "#00853F",
          lime: "#2ECC71",
          yellow: "#FDEF42",
          red: "#E31B23",
        },
        ink: "#1E1B4B",
      },
      boxShadow: {
        pop: "0 5px 0 0 #4B3FC4",
        popgreen: "0 5px 0 0 #006B33",
        card: "0 8px 24px -8px rgba(108, 92, 231, 0.35)",
      },
      keyframes: {
        floaty: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-6px)" },
        },
      },
      animation: {
        floaty: "floaty 3s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};

export default config;
