-- Généré par scripts/make-seed-sql.mjs — ne pas éditer à la main
-- À exécuter APRÈS supabase/schema.sql

begin;
delete from public.flashcards;
delete from public.quiz_questions;
delete from public.courses;

insert into public.courses (id, titre, niveau, matiere, emoji, duree_min, audio_url, resume) values ('algo-l1', 'Algorithmique', 'L1', 'informatique', '🧮', 14, null, '## Qu''est-ce qu''un algorithme ?
Un algorithme est une suite finie d''instructions non ambiguës qui permet de résoudre un problème.
## Les briques de base
- Variables : emplacements mémoire nommés et typés (entier, réel, booléen, caractère, chaîne).
- Conditions : SI … ALORS … SINON.
- Boucles : POUR (nombre de tours connu), TANT QUE (test avant), RÉPÉTER … JUSQU''À (test après).
## Tableaux et tris
Un tableau regroupe des éléments de même type, accessibles par un indice. Le tri à bulles compare les voisins et les échange : sa complexité est O(n²).
## Complexité
La complexité mesure le nombre d''opérations en fonction de la taille n des données. La recherche dichotomique, sur un tableau trié, est en O(log n).');
insert into public.flashcards (course_id, question, reponse) values ('algo-l1', 'Qu''est-ce qu''un algorithme ?', 'Une suite finie d''instructions non ambiguës qui résout un problème.');
insert into public.flashcards (course_id, question, reponse) values ('algo-l1', 'Différence entre TANT QUE et RÉPÉTER…JUSQU''À ?', 'TANT QUE teste avant d''exécuter (peut ne jamais s''exécuter) ; RÉPÉTER teste après (au moins une exécution).');
insert into public.flashcards (course_id, question, reponse) values ('algo-l1', 'Complexité du tri à bulles ?', 'O(n²) dans le pire des cas.');
insert into public.flashcards (course_id, question, reponse) values ('algo-l1', 'Condition pour utiliser la recherche dichotomique ?', 'Le tableau doit être trié. Complexité : O(log n).');
insert into public.flashcards (course_id, question, reponse) values ('algo-l1', 'Qu''est-ce qu''une variable ?', 'Un emplacement mémoire nommé et typé dont la valeur peut changer.');
insert into public.flashcards (course_id, question, reponse) values ('algo-l1', 'À quoi sert un indice dans un tableau ?', 'À accéder directement à un élément grâce à sa position.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('algo-l1', 'Quelle boucle s''exécute toujours au moins une fois ?', '["POUR","TANT QUE","RÉPÉTER … JUSQU''À","SI"]'::jsonb, 2, 'RÉPÉTER … JUSQU''À teste la condition APRÈS le corps de la boucle.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('algo-l1', 'Quelle est la complexité de la recherche dichotomique ?', '["O(n)","O(log n)","O(n²)","O(1)"]'::jsonb, 1, 'On divise l''espace de recherche par 2 à chaque étape : O(log n).');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('algo-l1', 'Que fait le tri à bulles ?', '["Il coupe le tableau en deux","Il compare et échange les voisins mal placés","Il cherche uniquement le minimum","Il utilise obligatoirement la récursivité"]'::jsonb, 1, 'Il parcourt le tableau en échangeant les éléments voisins qui sont dans le mauvais ordre.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('algo-l1', 'Quel type convient pour stocker vrai/faux ?', '["Entier","Réel","Booléen","Chaîne"]'::jsonb, 2, 'Le type booléen ne prend que deux valeurs : VRAI ou FAUX.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('algo-l1', 'Combien de tours fait « POUR i de 1 à 5 » ?', '["4","5","6","Infini"]'::jsonb, 1, 'i prend les valeurs 1, 2, 3, 4, 5 : soit 5 itérations.');

insert into public.courses (id, titre, niveau, matiere, emoji, duree_min, audio_url, resume) values ('prog-c', 'Programmation C', 'L1', 'informatique', '💻', 16, null, '## Structure d''un programme
Tout programme C possède une fonction main(). Les bibliothèques s''incluent avec #include, par exemple #include <stdio.h>.
## Types et entrées/sorties
- Types de base : int, float, double, char.
- printf affiche à l''écran, scanf lit au clavier (attention au & devant la variable).
## Pointeurs
Un pointeur contient l''adresse mémoire d''une variable. L''opérateur & donne l''adresse, l''opérateur * accède à la valeur pointée.
## Chaînes de caractères
Une chaîne est un tableau de char terminé par le caractère nul ''\0''.');
insert into public.flashcards (course_id, question, reponse) values ('prog-c', 'Quelle fonction est le point d''entrée d''un programme C ?', 'main()');
insert into public.flashcards (course_id, question, reponse) values ('prog-c', 'Que fait l''opérateur & ?', 'Il donne l''adresse mémoire d''une variable.');
insert into public.flashcards (course_id, question, reponse) values ('prog-c', 'Pourquoi écrit-on scanf("%d", &x) avec un & ?', 'scanf doit connaître l''adresse de x pour y écrire la valeur lue.');
insert into public.flashcards (course_id, question, reponse) values ('prog-c', 'Qu''est-ce qu''un pointeur ?', 'Une variable qui contient l''adresse mémoire d''une autre variable.');
insert into public.flashcards (course_id, question, reponse) values ('prog-c', 'Comment se termine une chaîne en C ?', 'Par le caractère nul ''\0''.');
insert into public.flashcards (course_id, question, reponse) values ('prog-c', 'Quel format utiliser pour afficher un entier avec printf ?', '%d');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('prog-c', 'Quelle bibliothèque faut-il inclure pour utiliser printf ?', '["stdlib.h","stdio.h","math.h","string.h"]'::jsonb, 1, 'printf et scanf sont déclarés dans stdio.h (standard input/output).');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('prog-c', 'Que vaut sizeof(char) ?', '["1 octet","2 octets","4 octets","8 octets"]'::jsonb, 0, 'Par définition, un char occupe 1 octet.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('prog-c', 'Après int *p = &x; que contient p ?', '["La valeur de x","L''adresse de x","Le double de x","Rien"]'::jsonb, 1, 'p stocke l''adresse de x, et *p donne la valeur de x.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('prog-c', 'Quel opérateur permet d''accéder à la valeur pointée ?', '["&","*","%","#"]'::jsonb, 1, '* est l''opérateur de déréférencement.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('prog-c', 'Combien de char occupe la chaîne "SEN" en mémoire ?', '["3","4","2","5"]'::jsonb, 1, '3 lettres + le caractère nul final = 4 char.');

insert into public.courses (id, titre, niveau, matiere, emoji, duree_min, audio_url, resume) values ('droit-constit', 'Droit Constitutionnel', 'L1', 'droit', '⚖️', 18, null, '## La Constitution
La Constitution est la norme suprême de l''État : elle organise les pouvoirs publics et garantit les droits et libertés des citoyens. Au Sénégal, la Constitution date du 22 janvier 2001 et a été révisée, notamment par le référendum de 2016.
## La séparation des pouvoirs
Théorisée par Montesquieu dans L''Esprit des lois (1748), elle distingue trois pouvoirs :
- Législatif : l''Assemblée nationale vote les lois.
- Exécutif : le Président et le Gouvernement appliquent les lois.
- Judiciaire : les juges tranchent les litiges.
## Hiérarchie des normes
Constitution > traités internationaux > lois > règlements. Le Conseil constitutionnel contrôle la conformité des lois à la Constitution.
## Pouvoir constituant
Le pouvoir constituant originaire crée une Constitution ; le pouvoir constituant dérivé la révise selon la procédure prévue.');
insert into public.flashcards (course_id, question, reponse) values ('droit-constit', 'Qui a théorisé la séparation des pouvoirs ?', 'Montesquieu, dans L''Esprit des lois (1748).');
insert into public.flashcards (course_id, question, reponse) values ('droit-constit', 'Quels sont les trois pouvoirs ?', 'Législatif, exécutif et judiciaire.');
insert into public.flashcards (course_id, question, reponse) values ('droit-constit', 'Durée du mandat présidentiel au Sénégal ?', '5 ans, renouvelable une seule fois (Constitution de 2001 révisée en 2016).');
insert into public.flashcards (course_id, question, reponse) values ('droit-constit', 'Rôle du Conseil constitutionnel ?', 'Contrôler la conformité des lois à la Constitution et veiller à la régularité des élections.');
insert into public.flashcards (course_id, question, reponse) values ('droit-constit', 'Qu''est-ce que la hiérarchie des normes ?', 'Le classement des règles de droit : Constitution > traités > lois > règlements.');
insert into public.flashcards (course_id, question, reponse) values ('droit-constit', 'Pouvoir constituant originaire vs dérivé ?', 'Originaire : crée une nouvelle Constitution. Dérivé : la révise selon la procédure prévue.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('droit-constit', 'Quelle norme est au sommet de la hiérarchie des normes ?', '["La loi","La Constitution","Le décret","Le règlement"]'::jsonb, 1, 'La Constitution est la norme suprême : toutes les autres doivent lui être conformes.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('droit-constit', 'Qui a écrit « L''Esprit des lois » ?', '["Rousseau","Montesquieu","Locke","Hobbes"]'::jsonb, 1, 'Montesquieu y expose la séparation des pouvoirs (1748).');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('droit-constit', 'Quelle est la durée du mandat du Président de la République du Sénégal ?', '["7 ans","5 ans","6 ans","4 ans"]'::jsonb, 1, 'Depuis la révision de 2016 : 5 ans, renouvelable une seule fois.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('droit-constit', 'Quel organe contrôle la constitutionnalité des lois ?', '["L''Assemblée nationale","Le Conseil constitutionnel","La Cour d''appel","Le Conseil des ministres"]'::jsonb, 1, 'Le Conseil constitutionnel vérifie la conformité des lois à la Constitution.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('droit-constit', 'Qui exerce le pouvoir législatif ?', '["Le Président seul","L''Assemblée nationale","Les tribunaux","L''armée"]'::jsonb, 1, 'Les députés de l''Assemblée nationale votent la loi.');

insert into public.courses (id, titre, niveau, matiere, emoji, duree_min, audio_url, resume) values ('compta-generale', 'Comptabilité Générale', 'L1', 'eco', '📒', 17, null, '## Le bilan
Le bilan est la photographie du patrimoine de l''entreprise à une date donnée. L''actif regroupe ce que l''entreprise possède (immobilisations, stocks, créances, trésorerie). Le passif regroupe ses ressources (capitaux propres et dettes). Équation fondamentale : Actif = Capitaux propres + Dettes.
## Le compte de résultat
Il compare les produits (ce que l''entreprise gagne) aux charges (ce qu''elle consomme). Résultat net = Produits − Charges : bénéfice si positif, perte si négatif.
## La partie double
Chaque opération est enregistrée au débit d''un compte et au crédit d''un autre, pour un même montant : total des débits = total des crédits.
## Référentiel
Au Sénégal, comme dans toute la zone OHADA, on applique le SYSCOHADA.');
insert into public.flashcards (course_id, question, reponse) values ('compta-generale', 'Équation fondamentale du bilan ?', 'Actif = Capitaux propres + Dettes (Passif).');
insert into public.flashcards (course_id, question, reponse) values ('compta-generale', 'Principe de la partie double ?', 'Chaque opération est inscrite au débit d''un compte et au crédit d''un autre pour le même montant.');
insert into public.flashcards (course_id, question, reponse) values ('compta-generale', 'Quel référentiel comptable est appliqué au Sénégal ?', 'Le SYSCOHADA (système comptable de la zone OHADA).');
insert into public.flashcards (course_id, question, reponse) values ('compta-generale', 'Différence entre charge et produit ?', 'Charge : ressource consommée (appauvrit). Produit : ressource gagnée (enrichit).');
insert into public.flashcards (course_id, question, reponse) values ('compta-generale', 'Comment calcule-t-on le résultat net ?', 'Produits − Charges. Positif = bénéfice, négatif = perte.');
insert into public.flashcards (course_id, question, reponse) values ('compta-generale', 'Que contient l''actif du bilan ?', 'Ce que l''entreprise possède : immobilisations, stocks, créances, trésorerie.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('compta-generale', 'Achat de marchandises payé comptant : quel compte est crédité ?', '["Banque / Caisse","Capital","Ventes","Clients"]'::jsonb, 0, 'L''argent sort de la caisse ou de la banque : on crédite ce compte de trésorerie.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('compta-generale', 'Produits = 5 000 000 F, charges = 3 500 000 F. Quel est le résultat ?', '["1 500 000 F de bénéfice","1 500 000 F de perte","8 500 000 F","0 F"]'::jsonb, 0, '5 000 000 − 3 500 000 = 1 500 000 F, positif donc bénéfice.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('compta-generale', 'Où figure le capital social ?', '["À l''actif","Au passif","Au compte de résultat","Nulle part"]'::jsonb, 1, 'Le capital fait partie des capitaux propres, donc du passif.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('compta-generale', 'En partie double, le total des débits est toujours…', '["Égal au total des crédits","Supérieur aux crédits","Inférieur aux crédits","Indépendant des crédits"]'::jsonb, 0, 'C''est le principe d''équilibre de la partie double.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('compta-generale', 'Un stock de marchandises est un élément de…', '["Passif","Actif circulant","Capitaux propres","Charges"]'::jsonb, 1, 'Le stock est un bien détenu par l''entreprise et destiné à être vendu : actif circulant.');

insert into public.courses (id, titre, niveau, matiere, emoji, duree_min, audio_url, resume) values ('anglais-l1', 'Anglais L1', 'L1', 'ena', '🇬🇧', 12, null, '## Present simple vs present continuous
- Present simple : habitudes et vérités générales (She studies every day). À la 3e personne du singulier, on ajoute -s.
- Present continuous : action en cours, am/is/are + verbe en -ing (I am studying now).
## Past simple
Les verbes réguliers prennent -ed ; les verbes irréguliers doivent être appris : go → went, buy → bought, write → wrote.
## Modal verbs
Must exprime l''obligation, can la capacité, should le conseil, might la possibilité.
## Since / for
Since indique le point de départ (since 2020), for indique la durée (for three years).');
insert into public.flashcards (course_id, question, reponse) values ('anglais-l1', 'When do we use the present simple?', 'For habits, routines and general truths (She studies every day).');
insert into public.flashcards (course_id, question, reponse) values ('anglais-l1', 'How do we form the present continuous?', 'am/is/are + verb-ing (I am studying).');
insert into public.flashcards (course_id, question, reponse) values ('anglais-l1', 'What is the past simple of « go » and « buy » ?', 'went and bought.');
insert into public.flashcards (course_id, question, reponse) values ('anglais-l1', 'What does « must » express?', 'Obligation or strong necessity.');
insert into public.flashcards (course_id, question, reponse) values ('anglais-l1', 'Difference between « since » and « for » ?', 'Since = starting point (since 2020). For = duration (for three years).');
insert into public.flashcards (course_id, question, reponse) values ('anglais-l1', 'What is the plural of « child » ?', 'Children (irregular plural).');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('anglais-l1', 'She ___ to UCAD every day.', '["go","goes","going","gone"]'::jsonb, 1, 'Present simple, 3e personne du singulier : on ajoute -es → goes.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('anglais-l1', 'What is the past simple of « write » ?', '["writed","wrote","written","writes"]'::jsonb, 1, 'Write → wrote → written : wrote est le prétérit.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('anglais-l1', 'I have lived here ___ 2019.', '["for","since","during","from"]'::jsonb, 1, 'Since introduit un point de départ dans le temps (2019).');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('anglais-l1', 'You ___ wear a helmet. It''s the law. (obligation)', '["might","must","would","could"]'::jsonb, 1, 'Must exprime une obligation forte.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('anglais-l1', 'What is the plural of « woman » ?', '["womans","womens","women","womanes"]'::jsonb, 2, 'Woman → women : pluriel irrégulier.');

insert into public.courses (id, titre, niveau, matiere, emoji, duree_min, audio_url, resume) values ('microeco-l1', 'Microéconomie', 'L1', 'eco', '📈', 15, null, '## Offre et demande
La loi de la demande dit que, toutes choses égales par ailleurs, quand le prix augmente, la quantité demandée diminue. À l''inverse, la quantité offerte augmente avec le prix.
## Équilibre de marché
L''équilibre est atteint au prix où la quantité offerte égale la quantité demandée. Si la demande dépasse l''offre, le prix monte ; dans le cas inverse, il baisse.
## Coût d''opportunité
C''est la valeur de la meilleure alternative sacrifiée quand on fait un choix.
## Élasticité
L''élasticité-prix mesure la sensibilité de la demande au prix. Si elle est supérieure à 1 en valeur absolue, la demande est élastique.
## Structures de marché
En monopole, un seul vendeur fixe le prix ; en concurrence parfaite, les vendeurs sont price takers.');
insert into public.flashcards (course_id, question, reponse) values ('microeco-l1', 'Que dit la loi de la demande ?', 'Toutes choses égales par ailleurs, quand le prix monte, la quantité demandée baisse.');
insert into public.flashcards (course_id, question, reponse) values ('microeco-l1', 'Qu''est-ce que l''équilibre de marché ?', 'Le prix pour lequel la quantité offerte est égale à la quantité demandée.');
insert into public.flashcards (course_id, question, reponse) values ('microeco-l1', 'Qu''est-ce que le coût d''opportunité ?', 'La valeur de la meilleure alternative abandonnée quand on fait un choix.');
insert into public.flashcards (course_id, question, reponse) values ('microeco-l1', 'Que mesure l''élasticité-prix de la demande ?', 'La variation en % de la quantité demandée quand le prix varie de 1 %.');
insert into public.flashcards (course_id, question, reponse) values ('microeco-l1', 'Bien normal vs bien inférieur ?', 'Bien normal : la demande augmente avec le revenu. Bien inférieur : elle diminue quand le revenu augmente.');
insert into public.flashcards (course_id, question, reponse) values ('microeco-l1', 'Qu''est-ce qu''un monopole ?', 'Un marché avec un seul vendeur, qui fixe le prix.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('microeco-l1', 'Selon la loi de la demande, si le prix augmente, la quantité demandée…', '["Augmente","Diminue","Reste identique","Double"]'::jsonb, 1, 'Relation inverse entre prix et quantité demandée.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('microeco-l1', 'Si la demande est supérieure à l''offre, le prix tend à…', '["Baisser","Monter","Rester stable","Devenir nul"]'::jsonb, 1, 'La pénurie pousse les prix à la hausse jusqu''à l''équilibre.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('microeco-l1', 'Le coût d''opportunité correspond à…', '["Les frais d''inscription uniquement","La meilleure alternative abandonnée","Un coût toujours nul","Le prix du transport"]'::jsonb, 1, 'C''est ce à quoi on renonce en faisant un choix.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('microeco-l1', 'La demande est élastique lorsque l''élasticité-prix en valeur absolue est…', '["Inférieure à 1","Supérieure à 1","Égale à 0","Toujours négative"]'::jsonb, 1, '|e| > 1 : la quantité réagit plus que proportionnellement au prix.');
insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values ('microeco-l1', 'Un monopole est un marché avec…', '["Plusieurs vendeurs","Un seul vendeur","Un seul acheteur","Aucun vendeur"]'::jsonb, 1, 'Monopole = un seul offreur. Un seul acheteur s''appelle un monopsone.');

commit;
