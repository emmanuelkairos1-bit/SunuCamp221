-- SamaCampus 221 — schéma Supabase
-- À coller dans Supabase > SQL Editor, puis exécuter. Ensuite exécuter supabase/seed.sql.

create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  pseudo text not null default 'Étudiant',
  universite text not null default 'UCAD' check (universite in ('UCAD','UGB','UVS','UADB')),
  xp integer not null default 0,
  streak integer not null default 0,
  last_active date,
  badges text[] not null default '{}',
  created_at timestamptz not null default now()
);

create table if not exists public.courses (
  id text primary key,
  titre text not null,
  niveau text not null default 'L1',
  matiere text,
  emoji text,
  duree_min integer not null default 15,
  audio_url text,
  resume text not null
);

create table if not exists public.flashcards (
  id bigint generated always as identity primary key,
  course_id text not null references public.courses(id) on delete cascade,
  question text not null,
  reponse text not null
);

create table if not exists public.quiz_questions (
  id bigint generated always as identity primary key,
  course_id text not null references public.courses(id) on delete cascade,
  question text not null,
  options jsonb not null,
  bonne_reponse integer not null check (bonne_reponse between 0 and 3),
  explication text
);

create table if not exists public.user_progress (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  course_id text not null references public.courses(id) on delete cascade,
  audio_pos real not null default 0,
  quiz_score integer not null default 0,
  xp integer not null default 0,
  completed boolean not null default false,
  updated_at timestamptz not null default now(),
  unique (user_id, course_id)
);

create index if not exists users_xp_idx on public.users (xp desc);
create index if not exists flashcards_course_idx on public.flashcards (course_id);
create index if not exists quiz_course_idx on public.quiz_questions (course_id);

-- Row Level Security
alter table public.users enable row level security;
alter table public.courses enable row level security;
alter table public.flashcards enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.user_progress enable row level security;

-- Contenu pédagogique : lisible par tout le monde
create policy "courses_read" on public.courses for select using (true);
create policy "flashcards_read" on public.flashcards for select using (true);
create policy "quiz_read" on public.quiz_questions for select using (true);

-- Classement : tout le monde peut lire pseudo / fac / xp ; chacun ne modifie que sa ligne
create policy "users_read" on public.users for select using (true);
create policy "users_insert_own" on public.users for insert with check (auth.uid() = id);
create policy "users_update_own" on public.users for update using (auth.uid() = id);

-- Progression : privée
create policy "progress_own_select" on public.user_progress for select using (auth.uid() = user_id);
create policy "progress_own_insert" on public.user_progress for insert with check (auth.uid() = user_id);
create policy "progress_own_update" on public.user_progress for update using (auth.uid() = user_id);

-- Création automatique du profil à l'inscription
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.users (id, pseudo, universite)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'pseudo', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'universite', 'UCAD')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
