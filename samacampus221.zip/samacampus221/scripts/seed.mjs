// Alternative au seed.sql : pousse data/courses.json dans Supabase via l'API.
// Usage : npm run seed   (nécessite SUPABASE_SERVICE_ROLE_KEY dans .env.local)
import { readFileSync } from "node:fs";
import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) {
  console.error("❌ Renseigne NEXT_PUBLIC_SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY dans .env.local");
  process.exit(1);
}

const sb = createClient(url, key, { auth: { persistSession: false } });
const courses = JSON.parse(readFileSync(new URL("../data/courses.json", import.meta.url), "utf8"));

for (const c of courses) {
  const { error } = await sb.from("courses").upsert({
    id: c.id,
    titre: c.titre,
    niveau: c.niveau,
    matiere: c.matiere,
    emoji: c.emoji,
    duree_min: c.duree_min,
    audio_url: c.audio_url,
    resume: c.resume,
  });
  if (error) throw error;

  await sb.from("flashcards").delete().eq("course_id", c.id);
  await sb.from("quiz_questions").delete().eq("course_id", c.id);

  const f = await sb.from("flashcards").insert(c.flashcards.map((x) => ({ course_id: c.id, question: x.q, reponse: x.a })));
  if (f.error) throw f.error;
  const z = await sb.from("quiz_questions").insert(
    c.quiz.map((x) => ({ course_id: c.id, question: x.q, options: x.options, bonne_reponse: x.answer, explication: x.explication }))
  );
  if (z.error) throw z.error;
  console.log(`✅ ${c.emoji} ${c.titre}`);
}
console.log("🎉 Seed terminé");
