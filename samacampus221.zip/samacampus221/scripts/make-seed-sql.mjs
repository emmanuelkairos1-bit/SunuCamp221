// Génère supabase/seed.sql à partir de data/courses.json
// Usage : npm run seed:sql
import { readFileSync, writeFileSync } from "node:fs";

const courses = JSON.parse(readFileSync(new URL("../data/courses.json", import.meta.url), "utf8"));
const q = (s) => (s === null || s === undefined ? "null" : `'${String(s).replace(/'/g, "''")}'`);

let sql = "-- Généré par scripts/make-seed-sql.mjs — ne pas éditer à la main\n";
sql += "-- À exécuter APRÈS supabase/schema.sql\n\n";
sql += "begin;\n";
sql += "delete from public.flashcards;\ndelete from public.quiz_questions;\ndelete from public.courses;\n\n";

for (const c of courses) {
  sql += `insert into public.courses (id, titre, niveau, matiere, emoji, duree_min, audio_url, resume) values (${q(c.id)}, ${q(c.titre)}, ${q(c.niveau)}, ${q(c.matiere)}, ${q(c.emoji)}, ${c.duree_min}, ${q(c.audio_url)}, ${q(c.resume)});\n`;
  for (const f of c.flashcards) {
    sql += `insert into public.flashcards (course_id, question, reponse) values (${q(c.id)}, ${q(f.q)}, ${q(f.a)});\n`;
  }
  for (const z of c.quiz) {
    sql += `insert into public.quiz_questions (course_id, question, options, bonne_reponse, explication) values (${q(c.id)}, ${q(z.q)}, ${q(JSON.stringify(z.options))}::jsonb, ${z.answer}, ${q(z.explication)});\n`;
  }
  sql += "\n";
}
sql += "commit;\n";

writeFileSync(new URL("../supabase/seed.sql", import.meta.url), sql);
console.log(`✅ supabase/seed.sql généré (${courses.length} cours)`);
