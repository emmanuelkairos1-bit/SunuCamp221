# 🎓 SamaCampus 221

App web mobile-first (PWA installable) pour réviser son semestre en 15 min/jour, inspirée de Yello et pensée pour les étudiants sénégalais.

**Stack :** Next.js 14 (App Router) · Tailwind CSS · Supabase (auth + BDD) · Framer Motion

## ✨ Fonctionnalités

| Page | Contenu |
|---|---|
| `/` | Accueil : hero, stats animées, 4 matières, défi du jour, liste des cours |
| `/cours/[id]` | Lecteur audio + onglets Audio / Résumé / Flashcards / Quiz + téléchargement hors-ligne |
| `/generate` | Colle ton cours → 10 flashcards retournables + 5 QCM (IA simulée) |
| `/quiz` | QCM chronométré (20 s), score, explications, XP, streak 🔥 |
| `/leaderboard` | Classement UCAD / UGB / UVS / Bambey + badges (Lève-tôt, Couche-tard, 100% Algo…) |
| `/login` | Inscription / connexion Supabase (mode démo local si non configuré) |

> **L'app fonctionne immédiatement sans Supabase** (mode démo : les 6 cours sont embarqués dans `data/courses.json`, la progression est sauvegardée dans le téléphone). Supabase ajoute les comptes, le classement réel et la synchronisation.

## 🚀 Lancer en local

Prérequis : Node.js 18.17+ (20+ recommandé).

```bash
npm install
cp .env.example .env.local     # optionnel pour tester en mode démo
npm run dev
```

Ouvre http://localhost:3000 (idéalement en mode mobile dans les outils de développement du navigateur).

> Le service worker (PWA / hors-ligne) n'est actif qu'en production : `npm run build && npm start`.

## 🗄️ Configurer Supabase

1. Crée un projet sur https://supabase.com
2. **SQL Editor** → colle et exécute `supabase/schema.sql` (tables `users`, `courses`, `flashcards`, `quiz_questions`, `user_progress`, règles RLS, trigger de création de profil).
3. Charge les 6 cours, au choix :
   - **Option A** : exécute `supabase/seed.sql` dans le SQL Editor ;
   - **Option B** : `npm run seed` (nécessite `SUPABASE_SERVICE_ROLE_KEY` dans `.env.local`).
   - Si tu modifies `data/courses.json`, régénère le SQL avec `npm run seed:sql`.
4. **Project Settings → API** : copie l'URL et la clé `anon` dans `.env.local` :
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
   ```
5. (Pour tester vite) **Authentication → Providers → Email** : désactive « Confirm email ».

### Ajouter de vrais fichiers audio
Les cours n'ont pas de MP3 au départ : le lecteur lit alors le résumé avec la voix du navigateur (fr-FR). Pour un vrai audio, uploade un MP3 dans **Storage** (bucket public), puis :
```sql
update public.courses set audio_url = 'https://xxxx.supabase.co/storage/v1/object/public/audio/algo.mp3' where id = 'algo-l1';
```

## ▲ Déployer sur Vercel

1. Pousse le projet sur GitHub :
   ```bash
   git init && git add . && git commit -m "SamaCampus 221"
   git remote add origin https://github.com/<toi>/samacampus221.git
   git push -u origin main
   ```
2. Sur https://vercel.com → **Add New → Project** → importe le dépôt (Next.js est détecté automatiquement).
3. **Environment Variables** : ajoute `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY` (n'ajoute **jamais** la clé service role sur Vercel).
4. **Deploy**. Puis dans Supabase → **Authentication → URL Configuration**, mets ton URL Vercel dans *Site URL*.

## 📲 Installer comme une app Android

Ouvre l'URL HTTPS déployée dans **Chrome Android** → bouton « 📲 Installer SamaCampus » en bas de l'accueil (ou menu ⋮ → *Ajouter à l'écran d'accueil*). L'app s'ouvre en plein écran avec son icône.

## 🧠 Comment marche le « mock IA »

`lib/mockAI.ts` simule l'IA sans API :
1. découpe le texte en phrases et repère les définitions (« X est / désigne / permet de… ») → cartes *question / réponse* ;
2. sinon crée des phrases à trous sur le mot-clé principal ;
3. détecte le thème (droit, algo, compta, éco, anglais, C) et complète avec des notions du programme pour toujours obtenir **10 flashcards + 5 QCM** ;
4. génère les QCM avec des distracteurs issus du texte.

Pour brancher une vraie IA plus tard : remplace `generate()` par un appel à une route API (`app/api/generate/route.ts`) qui appelle ton modèle et renvoie `{ flashcards, qcm }`.

## 🗂️ Structure

```
app/            pages (/, /cours/[id], /generate, /quiz, /leaderboard, /login)
components/     AudioPlayer, FlashcardDeck, BottomNav, AppHeader…
lib/            supabase.ts, data.ts, progress.ts (XP/streak/badges), mockAI.ts
data/           courses.json (6 cours L1 : source unique du contenu)
supabase/       schema.sql, seed.sql
public/         manifest.json, sw.js, icons/
scripts/        seed.mjs, make-seed-sql.mjs
```

## 🎮 Règles de gamification
- Bonne réponse : **10 XP + secondes restantes** (jusqu'à 30 XP) ; quiz parfait : **+20 XP**.
- Cours écouté en entier : +15 XP · toutes les flashcards maîtrisées : +30 XP · génération IA : +20 XP.
- 200 XP = 1 niveau. **Streak** : +1 par jour d'activité consécutif, retombe à 0 si tu rates un jour.
- Badges : 🌅 Lève-tôt (avant 8h) · 🦉 Couche-tard (après 22h) · 🧮 100% Algo · 🔥 Série de 3 · ⚡ Série de 7 · 🏆 Quiz Master.
